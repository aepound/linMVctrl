
This motion capture files are meant for free distribution, for educational purposes only.

Copyright of MocapClub.com

Download free additional motion capture files at:

www.mocapclub.com

ENJOY!!!
