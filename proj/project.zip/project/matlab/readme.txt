FILE DESCRIPTION

loading c3d file
loadc3d.m - wrapper file for readc3d.m
readc3d.m - read c3d file 

saving c3d file
savec3d.m - wrapper file for writec3d.m
writec3d.m - write c3d file 
find_c3d_parameter.m - used in savec3d.m and writec3d.m, search c3d parameters

* current saving function only works for storing marker data (x,y,z) and doesn't work for analog signal data
